Here is the example for LncTar 2.0. For more details how to use LncTar 2.0, please read LncTar 2.0 Manual.pdf.

Example of command line format:
	perl LncTar2.pl -l Examp1_lncRNA.txt -e lncRNA_Secondary_Structure.txt -m Examp1_mRNA.txt -a 8.5 -b -0.7 -d 0 -o out.txt
	
If it is a many-to-many situation, run the following command:
	perl LncTar2.pl -l many_Examp1_lncRNA.txt -e many_lncRNA_Secondary_Structure.txt -m many_Examp1_mRNA.txt -a 8.5 -b -0.7 -d 0 -o out.txt