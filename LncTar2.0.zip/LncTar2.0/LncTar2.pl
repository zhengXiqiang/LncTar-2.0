#!/usr/bin/perl -w

use Genecare::PerlOligos;
use strict;
use warnings;
use Getopt::Std;
use List::Util qw[min max];

my %opt=();
my $lncprimerfile='';
my $mRNAprimerfile='';
my $er='';
my $a='';
my $b='';
my $d='';
my @res = ();

my $pdm_result = "";
my @primers;
my @temp;
my @temp1;
my @para;
my @pdm_result;
my $list_len = 0;
my $lncPrimerCount=0;

if(@ARGV==14)
{
    if($ARGV[0] eq '-l')
    { $para[1]=$ARGV[1];}
    if($ARGV[2] eq '-l')
    { $para[1]=$ARGV[3];}
    if($ARGV[4] eq '-l')
    { $para[1]=$ARGV[5];}
    if($ARGV[6] eq '-l')
    { $para[1]=$ARGV[7];}
    if($ARGV[8] eq '-l')
    { $para[1]=$ARGV[9];}
    if($ARGV[10] eq '-l')
    { $para[1]=$ARGV[11];}
    if($ARGV[12] eq '-l')
    { $para[1]=$ARGV[13];}

    if($ARGV[0] eq '-e')
    { $para[3]=$ARGV[1];}
    if($ARGV[2] eq '-e')
    { $para[3]=$ARGV[3];}
    if($ARGV[4] eq '-e')
    { $para[3]=$ARGV[5];}
    if($ARGV[6] eq '-e')
    { $para[3]=$ARGV[7];}
    if($ARGV[8] eq '-e')
    { $para[3]=$ARGV[9];}
    if($ARGV[10] eq '-e')
    { $para[3]=$ARGV[11];}
    if($ARGV[12] eq '-e')
    { $para[3]=$ARGV[13];}

    if($ARGV[0] eq '-m')
    { $para[5]=$ARGV[1];}
    if($ARGV[2] eq '-m')
    { $para[5]=$ARGV[3];}
    if($ARGV[4] eq '-m')
    { $para[5]=$ARGV[5];}
    if($ARGV[6] eq '-m')
    { $para[5]=$ARGV[7];}
    if($ARGV[8] eq '-m')
    { $para[5]=$ARGV[9];}
    if($ARGV[10] eq '-m')
    { $para[5]=$ARGV[11];}
	if($ARGV[12] eq '-m')
    { $para[5]=$ARGV[13];}

    if($ARGV[0] eq '-a')
    { $para[7]=$ARGV[1];}
    if($ARGV[2] eq '-a')
    { $para[7]=$ARGV[3];}
    if($ARGV[4] eq '-a')
    { $para[7]=$ARGV[5];}
    if($ARGV[6] eq '-a')
    { $para[7]=$ARGV[7];}
    if($ARGV[8] eq '-a')
    { $para[7]=$ARGV[9];}
    if($ARGV[10] eq '-a')
    { $para[7]=$ARGV[11];}
	if($ARGV[12] eq '-a')
    { $para[7]=$ARGV[13];}

    if($ARGV[0] eq '-b')
    { $para[9]=$ARGV[1];}
    if($ARGV[2] eq '-b')
    { $para[9]=$ARGV[3];}
    if($ARGV[4] eq '-b')
    { $para[9]=$ARGV[5];}
    if($ARGV[6] eq '-b')
    { $para[9]=$ARGV[7];}
    if($ARGV[8] eq '-b')
    { $para[9]=$ARGV[9];}
    if($ARGV[10] eq '-b')
    { $para[9]=$ARGV[11];}
	if($ARGV[12] eq '-b')
    { $para[9]=$ARGV[13];}

    if($ARGV[0] eq '-d')
    { $para[11]=$ARGV[1];}
    if($ARGV[2] eq '-d')
    { $para[11]=$ARGV[3];}
    if($ARGV[4] eq '-d')
    { $para[11]=$ARGV[5];}
    if($ARGV[6] eq '-d')
    { $para[11]=$ARGV[7];}
    if($ARGV[8] eq '-d')
    { $para[11]=$ARGV[9];}
    if($ARGV[10] eq '-d')
    { $para[11]=$ARGV[11];}
	if($ARGV[12] eq '-d')
    { $para[11]=$ARGV[13];}

    if($ARGV[0] eq '-o')
    { $para[13]=$ARGV[1];}
    if($ARGV[2] eq '-o')
    { $para[13]=$ARGV[3];}
    if($ARGV[4] eq '-o')
    { $para[13]=$ARGV[5];}
    if($ARGV[6] eq '-o')
    { $para[13]=$ARGV[7];}
    if($ARGV[8] eq '-o')
    { $para[13]=$ARGV[9];}
    if($ARGV[10] eq '-o')
    { $para[13]=$ARGV[11];}
	if($ARGV[12] eq '-o')
    { $para[13]=$ARGV[13];}
}

$lncprimerfile=$para[1];
$er=$para[3];
$mRNAprimerfile=$para[5];
$a=$para[7];
$b=$para[9];
$d=$para[11];
$pdm_result=$para[13];

if((!$lncprimerfile)||(!$er)||(!$mRNAprimerfile)||(!$a)||(!$b)||(!$pdm_result)) {
    print "param error,please check carefully.\n";
    exit;
}

open (LOGF, ">$pdm_result")||die"can not open pdm_result!\n";
close LOGF;     #clear the file of pdm_result
push (@res,"Note：In the generated results, the \"*\" sign indicates the lncRNA secondary structure region, the \".\" indicates that the base is not paired, and \"|\" indicates the base pair.\n\n");
push (@res,"Query\tLength_Query\tTarget\tLength_Target\tdG\tndG\tStart_Position_Query\tEnd_Position_Query\tStart_Position_Target\tEnd_Position_Target\tdndG\tDiff.(ndG-dndG)\n");
open(PDM,">>$pdm_result") or die "Can't open file $pdm_result : No such file or directory!\n";
print PDM @res;
close (PDM);

open(LNCRNA,"<$lncprimerfile")||die "Can't open $lncprimerfile";
open(LNCTEMP,">lnc_temp.txt")||die "nonononono";
my $flag = 1;
my @temp_lnc;
my @temp_m;
my @temp_er;

while(<LNCRNA>) {
    my $temp_line = $_;
    chomp($temp_line);
    $temp_line =~ s/(^\s+|\s+$)//g;
    $temp_line =~ s/[\r]$//g;

    if ($temp_line=~/^>/) {
        @temp_lnc =split(/\s+/,$temp_line);

        if($temp_lnc[1]) {
            print "the format of file is error, Please check! The name and the sequence do not put in a row!\n ";
            exit;
        }
        if($flag==1) {
            $temp_line = $temp_line."\n";
            $flag=$flag+1;
        } else {
            $temp_line = "\n".$temp_line."\n";
        }
    } elsif ($flag==1) {
    print "the format of file is error,maybe you didn't input the name of the sequence or the name didn't start with \">\"!\n ";
    exit;
    }
    print LNCTEMP $temp_line;
}
close LNCRNA;
close LNCTEMP;

open(ERLNC,"<$er")||die "Can't open $er";
open(ERTEMP,">er_temp.txt")||die "nonononono";
my $flag2 = 1;
while(<ERLNC>) {
    my $temp_line2 = $_;

    chomp($temp_line2);
    $temp_line2 =~ s/(^\s+|\s+$)//g;
    $temp_line2 =~ s/[\r]$//g;

    if ($temp_line2=~/^>/) {
        @temp_er =split(/\s+/,$temp_line2);

        if($temp_er[1]) {
            print "the format of file is error, Please check! The name and the sequence do not put in a row!\n ";
            exit;
        }
        if($flag2==1) {
            $temp_line2 = $temp_line2."\n";
            $flag2=$flag2+1;
        } else {
            $temp_line2 = "\n".$temp_line2."\n";
        }
    } elsif ($flag2==1) {
		print "the format of file is error,maybe you didn't input the name of the sequence or the name didn't start with \">\"!\n ";
		exit;
    }

    print ERTEMP $temp_line2;
}
close ERLNC;
close ERTEMP;


open(MRNA,"<$mRNAprimerfile")||die "Can't open $mRNAprimerfile";
open(MRNATEMP,">mRNA_temp.txt")||die "nonononono";
my $flag1 = 1;
while(<MRNA>) {
    my $temp_line1 = $_;
    chomp($temp_line1);
    $temp_line1 =~ s/(^\s+|\s+$)//g;
    $temp_line1 =~ s/[\r]$//g;
    if ($temp_line1=~/^>/)
    {
        @temp_m =split(/\s+/,$temp_line1);
        if($temp_m[1])
        {
            print "the format of file is error,Please check! The name and the sequence do not put in a row!\n ";
            exit;
        }
        if($flag1==1)
        {
            $temp_line1 = $temp_line1."\n";
            $flag1=$flag1+1;
        }
        else
        {
            $temp_line1 = "\n".$temp_line1."\n";
        }
    }
    elsif ($flag1==1)
    {
        print "the format of file is error,maybe you didn't input the name of the sequence!\n ";
        exit;
    }
    print MRNATEMP $temp_line1;
}
close MRNA;
close MRNATEMP;

open (PRIMER_FILE, "<lnc_temp.txt") or die "Can't open file $lncprimerfile : No such file or directory!\n";
open (ER_FILE, "<er_temp.txt") or die "Can't open file $er : No such file or directory!\n";
my $line = "";
my $line2 = "";
my $er_tem = "";
while (defined($line=<PRIMER_FILE>) && defined($line2=<ER_FILE>)) {
	$list_len=0;
	# my $line = $_;
	# my $line2 = $_;
	# print($line);
	# print($line2);
	chomp($line);
	$line =~ s/(^s+|s+$)//g;#clear the space both
	if($line =~ /^>/)
	{
		$temp[0]=substr($line,1);#save the name of lncRNA
	}
	next if($line =~ /^>/);
	if($line =~ /^(A|T|C|G|a|t|c|g)/){
		$temp[1]=$line;
		$temp[1]=~s///g;
		$temp[1]=~s/ //g;
		$temp[1]=~s/u/t/g;
		$temp[1]=~s/U/T/g;
		$temp[1]=~s/\n//g;
		push (@primers, [@temp]);
		$er_tem=$line2;
		$list_len++;
		open (MRNA_FILE,"<mRNA_temp.txt") or die "Can't open file $mRNAprimerfile : No such file or directory!\n";
		while(<MRNA_FILE>)
		{
			my $line1 = $_;
			chomp($line1);
			$line1 =~ s/\s+$//;
			if($line1 =~ /^>/)
			{
				$temp1[0]=substr($line1,1);
			}
			next if($line1 =~ /^>/);
			if($line1 =~ /^(A|T|C|G|a|t|c|g)/){
				$temp1[1]=$line1;
				$temp1[1]=~s///g;
				$temp1[1]=~s/u/t/g;
				$temp1[1]=~s/U/T/g;
				$temp1[1]=~s/ //g;
				$temp1[1]=~s/\n//g;
				push (@primers, [@temp1]);
				$list_len++;
			}
			else{
				print "the format of file (-m) is error,Please check.\n ";
				exit;
			}
		}
	}

    my $index=$lncPrimerCount/50;
    my $nowCount=0;
    while($index>0)
    {
        $index--;
        $nowCount++;
    }
    if($index<0)
    {
        $nowCount--;
    }
    for (my $i = 0; $i <=0; $i++) {
		chomp($er_tem);
		for (my $j =$i+1; $j <= $list_len-1; $j++) {
			cal_dimer($primers[$i][0], $primers[$i][1],$er_tem, $primers[$j][0], $primers[$j][1],$a,$b,$d,$pdm_result);
			}
	}
    $lncPrimerCount++;
    @temp=();
    @primers=();
    close MRNA_FILE;
}
close ER_FILE;
close PRIMER_FILE;