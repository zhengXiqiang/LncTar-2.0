#!/usr/bin/perl
package Genecare::PerlOligos;
use Exporter;
use vars qw/@ISA @EXPORT $VERSION/;
use strict;
use List::Util qw(min max maxstr);
#user warnings;
@ISA = ('Exporter');
@EXPORT = qw/cal_dimer gc/; # subs to export


my ($fpname, $fprimer, $lncStructure, $rpname, $rprimer,$c,$e,$d,$output);

my @result = ();
my @result1 = ();

my $oligo_conc = 200; #in nM
my $mg_conc=0.7; #in mM
my $monovalent_cation_conc=50; #in mM
my $dntp_conc=0.2; #in mM

my $repeat = 3;
my $run = 4;
my $numlnc=0;
my $reverse_primer_f;
my $reverse_primer_r;

my $baoding=0;

# Primer-dimer parameters
my $pd_full=0;
my $pd_extensible=1;
my $pd_temperature=37;
my $min_leng=0;
my $sdelta=0;
# More global variables

my $pos_a=0;
my $pos_b=0;

my $number_1=0;
my $number_2=0;
my $number_3=0;
my $number_4=0;
my $number_5=0;
my $number_6=0;

my $score_1=0;
my $score_2=0;

our @primer_comp;

my (
	$primer_f, $primer_r, $pos,
	$rprimer_r,
	$pd, @score_sort, $reverse,
	$pfkeys, $pkeys, @PF, @PR, %primer_hash,
	$gc_exclude, $gc_percent_ex, @primer_pairs,
	$prl, $pfl, $pl, @bind_string, %rating_hash, @score,@init, @end,@gc_number,@number,@mumber,@score_pp,@one_pp,@lec,
	$fprimer_tm, $fprimer_len, $fprimer_ds, $fprimer_dh, $fprimer_dg, $fprimer_gc,
	$rprimer_tm, $rprimer_len, $rprimer_ds, $rprimer_dh, $rprimer_dg, $rprimer_gc,
);

my %oligo_dG=(
	qw(TTAA -0.93	AATT -0.93
		ATTA -1.10
		TAAT -1.33
		CTGA -2.08	AGTC -2.08
		CAGT -2.11	TGAC -2.11
		GTCA -2.24	ACTG -2.24
		GACT -2.35	TCAG -2.35
		CGGC -2.36
		GGCC -3.26	CCGG -3.26
		GCCG -3.42
		AT 0.45 TA 0.45
		
		AGTT -0.55	TTGA -0.55
		ATTG -1.36	GTTA -1.36
		CGGT -1.41	TGGC -1.41
		CTGG -2.11	GGTC -2.11
		GGCT -1.53	TCGG -1.53
		GTCG -2.51	GCTG -2.51
		GATT -1.27	TTAG -1.27
		GGTT 0.47	TTGG 0.47
		GTTG 1.29
		GGTCCTGG -4.12 
		TGAT -1.00 TAGT -1.00
		TGGT 0.3
		GT 0.45 TG 0.45
		), 
);

sub cal_dimer {
	($fpname, $fprimer, $lncStructure, $rpname, $rprimer,$c,$e,$d,$output) = @_;# argument list
	@result=();
	get_tm($fprimer,$lncStructure,$rprimer,$a,$b,$d,$output);
}

sub get_tm {
	my ($report) = @_;
	$fprimer = uc($fprimer);
	$rprimer = uc($rprimer);

	if ($fprimer && !check_degenerate($fprimer, 1)) {
		$fprimer_gc = int(gc($fprimer));
		$fprimer_len = length($fprimer);
	} else {exit;}	
	if ($rprimer && !check_degenerate($rprimer, 1)) {
		$rprimer_gc = int(gc($rprimer));
		$rprimer_len = length($rprimer);
	}else {exit;}
	
	print "lncRNA is :$fpname, length : $fprimer_len\t";
	print "mRNA is : $rpname,  length :$rprimer_len\n";

	my $score_1;
	my $score_2;
	
	if ($rprimer && !check_degenerate($rprimer)) {

		primer_dimer($fprimer,$lncStructure,$rprimer,1);
		$score_1=$score_sort[0];
		$pos_a=$rating_hash{$score_sort[0]};
		$reverse_primer_r=reverse($rprimer);
		primer_dimer($fprimer,$lncStructure,$reverse_primer_r,1);
		$score_2=$score_sort[0];
		$pos_b=$rating_hash{$score_sort[0]};
		
		my @out_l=split(/\./,$output);
		
		if($score_1<=$score_2) { 
			$score_sort[0] = $score_1;
			$pos=$pos_a;
			primer_dimer($fprimer,$lncStructure,$rprimer,1);
			if ($score_sort[0]<0) {
				draw_dimer($fprimer,$rprimer,$pos,$score_sort[0],$c,$e,$d);
				open(PDM,">>$output") or die "Can't open file: $!\n";
				print PDM @result;
				close (PDM);
				open(PDM,">>".$out_l[0]."_concise.txt") or die "Can't open file: $!";
				print PDM @result1;
				close (PDM);
				$numlnc++;
			}
		}
		if($score_1>$score_2) { 
			$score_sort[0] = $score_2;
			$pos=$pos_b;
			if ($score_sort[0]<0) {
				draw_dimer($fprimer,$reverse_primer_r, $pos,$score_sort[0],$c,$e,$d);
				open(PDM,">>$output") or die "Can't open file: $!";
				print PDM @result;
				close (PDM);
				open(PDM,">>".$out_l[0]."_concise.txt") or die "Can't open file: $!";
				print PDM @result1;
				close (PDM);
				$numlnc++;
			}
		}
	}
}

sub check_degenerate {
	$_ = shift;
	if (/[^ATGC]/i) {
		print "One of your sequences has a degenerate or non-DNA character,please check\n";
		return 1;
	} 
}

# %GC
sub gc {
	$_ = $_[0];
	my($gc,$countgc,$counttotal);
	$gc=0;
	$countgc=0;
		
	$countgc = tr/GCgc/GCgc/;
	$counttotal = length();
	
	$gc = $countgc/$counttotal*100;
	return $gc;
}

sub func1{
	my $bind=$_[0];
	my $k=$_[1];
	my $primer_f=$_[2];
	my $pfl=$_[3];
	my $rprimer_r=$_[4];
	my $tem_init=$_[5];
	my $tem_end=$_[6];
	my $m;
	my $i;
	my $n;
	my $p=0;
	my $count;
	my $str1;
	my $num=0;
	my $str2;
	my $str3;
	my $start_d=0;
	my $j;
	my $q;
	my $dind6;
	my $z;
	my $score_z;
	my $score_y;
	for($m=$tem_init; $m<=$tem_end; $m += $count){

		if(substr($bind, $m, 1) eq "3") {
			# print("$bind\n");
			$p=$m; 
			$str1="";
			while(substr($bind, $p, 1) eq "3"){
				$str1 .= "3";
				$p+=1;
			}
			$count=$p-$m;
			$n=$p;
			my $lent=length($str1);
			my $str2="";
			while(length($str1)>0&&$n<length($bind)){
				if(substr($bind, $n,1) eq "3") {
					$str2 .= "3";
				}elsif(substr($bind, $n, 1) eq "4") {
					if(length($str2)!=0){
						$str2=substr($str2,0,length($str2)-1);
					}else{
						$str1=substr($str1,0,length($str1)-1);
					}
				}elsif(substr($bind, $n-1, 2) eq "40" || substr($bind, $n-1, 2) eq "41") {
					$count=length($str1);
					$p=$m+$count;
				}
				$n+=1;
			}
			
			if(length($str1)==0) {
				
				# print("$bind\n");
				if($m-$count>=0){
					$start_d = $m-$count;
				}else{
					$start_d = 0;
				}
				while($start_d-1>=0 && substr($bind, $start_d-1, 1) eq "1") {
					$start_d=$start_d-1;
				}
				$score_z=0;
				
				my $ee=$bind;
				my $dind9 = substr($ee,0,$m);
				my $dind10 = substr($ee,$p);
				for $i($m..$p-1) {
					$dind9 .= $primer_comp[$i][$k-$i];
				}
				$dind9 .= $dind10;
				$ee=$dind9;
				
				my $temp=$count+$p;
				while(substr($bind, $temp, 1) eq "1"){
					$temp=$temp+1;
				}
				
				for $z ($start_d .. $temp-2) {
					next if $z>=length($ee)-1;
					next if substr($ee, $z, 2) eq "00";
					next if substr($ee, $z, 2) eq "03";
					next if substr($ee, $z, 2) eq "02";
					next if substr($ee, $z, 2) eq "04";
					next if substr($ee, $z, 2) eq "01";
					next if substr($ee, $z, 2) eq "12";
					next if substr($ee, $z, 2) eq "13";
					next if substr($ee, $z, 2) eq "14";
					next if substr($ee, $z, 2) eq "10";
					next if substr($ee, $z, 1) eq "2";
					next if substr($ee, $z, 1) eq "3";
					next if substr($ee, $z, 1) eq "4";
					$score_z+=$oligo_dG{substr($primer_f, $pfl-$k+$z-1, 2).substr($rprimer_r, $z, 2)};
				}
				

				
				my $g = $n-$count*2;
				while(substr($bind, $g-1, 1) eq "1"){
					$g=$g-1;
				}
				my $h = $n;
				$a=$n-$count;
				my $dind7 = substr($ee,0,$a);
				my $dind8 = substr($ee,$h);
				for $i($a..$h-1) {
					$dind7 .= $primer_comp[$i][$k-$i];
				}
				$dind7 .= $dind8;
				$ee = $dind7;
				
				my $temp_1=$count+$h;
				while($temp_1<=length($bind)-1 && substr($bind, $temp_1, 1) eq "1"){
					$temp_1=$temp_1+1;
				}
				
				for $z ($g .. $temp_1-2) {
					next if $z>=length($ee)-1;
					next if substr($ee, $z, 2) eq "00";
					next if substr($ee, $z, 2) eq "03";
					next if substr($ee, $z, 2) eq "02";
					next if substr($ee, $z, 2) eq "04";
					next if substr($ee, $z, 2) eq "01";
					next if substr($ee, $z, 2) eq "12";
					next if substr($ee, $z, 2) eq "13";
					next if substr($ee, $z, 2) eq "14";
					next if substr($ee, $z, 2) eq "10";
					next if substr($ee, $z, 1) eq "2";
					next if substr($ee, $z, 1) eq "3";
					next if substr($ee, $z, 1) eq "4";
					
					$score_z+=$oligo_dG{substr($primer_f, $pfl-$k+$z-1, 2).substr($rprimer_r, $z, 2)};
				}

				
				my $stem = substr($primer_f, $pfl-$k+$m-1, $count);
				my $stem_r = complement($stem);
				$score_y=0.43;
				
				if(substr($stem, 0, 1).substr($stem_r, 0, 1) eq "AT" 
				|| substr($stem, 0, 1).substr($stem_r, 0, 1) eq "TA") {
					$score_y+=$oligo_dG{substr($stem, 0, 1).substr($stem_r, 0, 1)};
				}
				
				for $z (0 .. length($stem)-2) {
					$score_y+=$oligo_dG{substr($stem, $z, 2).substr($stem_r, $z, 2)};
				}
				
				if(substr($stem, length($stem)-1, 1).substr($stem_r, length($stem)-1, 1) eq "AT" 
				|| substr($stem, length($stem)-1, 1).substr($stem_r, length($stem)-1, 1) eq "TA") {
					$score_y+=$oligo_dG{substr($stem, length($stem)-1, 1).substr($stem_r, length($stem)-1, 1)};
				}
				
				if(abs($score_z)>=abs($score_y)){
					my $dind1 = substr($bind,0,$m);
					my $dind2 = substr($bind,$p,length($bind)-$p);
					for $i($m..$p-1) {
						$dind1 .= $primer_comp[$i][$k-$i];
					}
					$dind1 .= $dind2;
					$bind=$dind1;
					
					$n=$n-$count;
					my $dind3 = substr($bind,0,$n);
					my $dind4 = substr($bind,$h,length($bind)-$h);
					# print("n=$n\n");
					for $i($n..$h-1) {
						$dind3 .= $primer_comp[$i][$k-$i];
					}
					$dind3 .= $dind4;
					$bind = $dind3;
				}
			}
		}
		elsif(substr($bind, $m, 1) eq "4") {

			$p=$m;
			$str1="";
			while(substr($bind, $p, 1) eq "4"){
				$str1 .= "4";
				$p+=1;
			}
			$count=$p-$m;
			my $dind6 = reverse(substr($bind,0,$m));
			# print("$dind6\n");
			$n=0;
			my $str2="";
			while(length($str1)>0&&$n<length($dind6)&&2!=substr($dind6, $n,1)){
				if(substr($dind6, $n,1) eq "4") {
					$str2 .= "4";
				}elsif(substr($dind6, $n,1) eq "3") {
					if(length($str2)!=0){
						$str2=substr($str2,0,length($str2)-1);
					}else{
						$str1=substr($str1,0,length($str1)-1);
					}
				}elsif(substr($dind6, $n-1, 2) eq "03" || substr($dind6, $n-1, 2) eq "13") {
					$count=length($str1);
					$p=$m+$count;
				}
				$n+=1;
			}
			
			if(length($str1)==0){

				$start_d=$m-$count;
				while(substr($bind, $start_d-1, 1) eq "1") {
					$start_d=$start_d-1;
				}
				$score_z=0;
				
				my $ee=$bind;
				my $dind9 = substr($ee,0,$m);
				my $dind10 = substr($ee,$p,length($ee)-$p);
				for $i($m..$p-1) {
					$dind9 .= $primer_comp[$i][$k-$i];
				}
				$dind9 .= $dind10;
				$ee=$dind9;
				
				my $temp_2=$count+$p;
				while($temp_2<=length($bind)-1 && substr($bind, $temp_2, 1) eq "1"){
					$temp_2=$temp_2+1;
				}
				
				for $z ($start_d .. $temp_2-2) {
					next if $z>=length($ee)-1;
					next if substr($ee, $z, 2) eq "00";
					next if substr($ee, $z, 2) eq "03";
					next if substr($ee, $z, 2) eq "02";
					next if substr($ee, $z, 2) eq "04";
					next if substr($ee, $z, 2) eq "01";
					next if substr($ee, $z, 2) eq "12";
					next if substr($ee, $z, 2) eq "13";
					next if substr($ee, $z, 2) eq "14";
					next if substr($ee, $z, 2) eq "10";
					next if substr($ee, $z, 1) eq "2";
					next if substr($ee, $z, 1) eq "3";
					next if substr($ee, $z, 1) eq "4";

					$score_z+=$oligo_dG{substr($primer_f, $pfl-$k+$z-1, 2).substr($rprimer_r, $z, 2)};
				}
				
				my $g;
				if(length($dind6)-$n-$count>=0){
					$g = length($dind6)-$n-$count;
				}else{
					$g = 0;
				}
				while($g-1>=0 && substr($bind, $g-1, 1) eq "1"){
					$g=$g-1;
				}
				
				my $h = length($dind6)-$n+$count;
				my $dind7 = substr($ee,0,$h-$count);
				my $dind8 = substr($ee,$h);
				for $i($h-$count..$h-1) {
					$dind7 .= $primer_comp[$i][$k-$i];
				}
				$dind7 .= $dind8;
				$ee = $dind7;
				
				my $temp_3=$count+$h;
				while(substr($bind, $temp_3, 1) eq "1"){
					$temp_3=$temp_3+1;
				}
				
				for $z ($g .. $temp_3-2) {
					next if $z>=length($ee)-1;
					next if substr($ee, $z, 2) eq "00";
					next if substr($ee, $z, 2) eq "03";
					next if substr($ee, $z, 2) eq "02";
					next if substr($ee, $z, 2) eq "04";
					next if substr($ee, $z, 2) eq "01";
					next if substr($ee, $z, 2) eq "12";
					next if substr($ee, $z, 2) eq "13";
					next if substr($ee, $z, 2) eq "14";
					next if substr($ee, $z, 2) eq "10";
					next if substr($ee, $z, 1) eq "2";
					next if substr($ee, $z, 1) eq "3";
					next if substr($ee, $z, 1) eq "4";
					$score_z+=$oligo_dG{substr($primer_f, $pfl-$k+$z-1, 2).substr($rprimer_r, $z, 2)};
				}

				my $stem = substr($primer_f, $pfl-$k+$m-1, $count);
				my $stem_r = complement($stem);
				$score_y=0.43;
				
				if(substr($stem, 0, 1).substr($stem_r, 0, 1) eq "AT"
				|| substr($stem, 0, 1).substr($stem_r, 0, 1) eq "TA") {
					$score_y+=$oligo_dG{substr($stem, 0, 1).substr($stem_r, 0, 1)};
				}
				
				for $z (0 .. length($stem)-2) {
					$score_y+=$oligo_dG{substr($stem, $z, 2).substr($stem_r, $z, 2)};
				}
				
				if(substr($stem, length($stem)-1, 1).substr($stem_r, length($stem)-1, 1) eq "AT" 
				|| substr($stem, length($stem)-1, 1).substr($stem_r, length($stem)-1, 1) eq "TA") {
					$score_y+=$oligo_dG{substr($stem, length($stem)-1, 1).substr($stem_r, length($stem)-1, 1)};
				}
				
				if(abs($score_z)>=abs($score_y)){
					my $dind1 = substr($bind,0,$m);
					my $dind2 = substr($bind,$p,length($bind)-$p);
					for $i($m..$p-1) {
						$dind1 .= $primer_comp[$i][$k-$i];
					}
					$dind1 .= $dind2;
					$bind=$dind1;
					
					my $dind3 = substr($bind,0,$h-$count);
					my $dind4 = substr($bind,$h,length($bind)-$h);
					for $i($h-$count..$h-1) {
						$dind3 .= $primer_comp[$i][$k-$i];
					}
					$dind3 .= $dind4;
					$bind = $dind3;
				}
			}
		}
		else {
			$count=1;
		}
	}
	return $bind;
}

sub primer_dimer {
		
	my ($primer_f,$lncStructure,$primer_r, $pd_full) = @_;     #lncRNA，mRNA, 1
	return unless ($primer_f) && ($primer_r);

	my ($k, $l);
	
	@score=();
	@score_pp=();
	@one_pp=();
	%primer_hash=();
	@score_sort=();
	@bind_string=();
	%rating_hash=();

	# $pl = greatest length
	$pfl=length($primer_f);
	$prl=length($primer_r); 

	my $dd = $lncStructure,;

	$pl = ($pfl>$prl ? $pfl : $prl);
	my $rcompr = reverse(complement($primer_r));
	my $rcomprlc = lc($rcompr);
	my $fprimer_r=lc(reverse($primer_f));
	$rprimer_r=reverse($primer_r);

	# create a binding array for each of the four bases
	for $l (0 .. $pfl-1) {
		my $mbase = substr($fprimer_r, $l, 1);
		$primer_hash{$mbase}[$l]=1;
		for $k (qw/a g c t/) {
			$primer_hash{$k}[$l] ||=0;
		}
	}
	
	# create the primer matrix
	for $k (0 .. $prl-1) {
		$primer_comp[$k]=$primer_hash{substr($rcomprlc, $k, 1)};
	}
	
	# read each combination from the matrix, calculate dG for each dimer
	my $pd_len = ($pd_full ? $pfl+$prl-1 : $pl-2);
	
	for $k (0 .. $pd_len) {
		$score[$k]=0;
		$score_pp[$k]=0;
		$one_pp[$k]=0;
		my $bind;
		my $bind1;
		my $bind_5;
		my $score_p=4.09;
		my $score_y=4.09;
		my $score_H=3.61;
		my $score_y_temp=0;
		my $number=0;
		
		my $bb = reverse($dd);
		
		# extensible primer short-circuit - ignore all primers that will
		# not create extensible (i.e. amplifiable) dimers
		my $start = $k>$pfl-1 ? $pfl-1 : $k;
		my $end = $k>$prl-1 ? $prl-1 : $k;
		if ($pd_extensible && !$pd_full) {
			next unless $primer_comp[0][$start] == 1;
			next unless $primer_comp[$end][$start-$k] == 1;
		}

		# read the binding data
		for $l (0 .. $prl-1) {
			if (($k-$l)<$pfl) {
				if (($k-$l)>=0) {
					if(substr($bb, $k-$l, 1) eq "(") {
						$bind .= "3";
					}elsif(substr($bb, $k-$l, 1) eq ")") {
						$bind .= "4";
					}
					else{
						$bind .= $primer_comp[$l][$k-$l];
					}
				}
			} else {
				# spacer
				$bind .= "2";
			}
		}
		
		for $l (0 .. $prl-1) {
			if (($k-$l)<$pfl) {
				$bind_5 .= $primer_comp[$l][$k-$l] if ($k-$l)>=0;
			} else {
				# spacer
				$bind_5 .= "2";
			}
		}
		
		#GU pair
		for(my $rr=0;$rr<length($bind);$rr++) {
			if(substr($bind, $rr, 1) eq "0") {
				if(substr($primer_f, $pfl-$k+$rr-1, 1).substr($rprimer_r, $rr, 1) eq "TG" || substr($primer_f, $pfl-$k+$rr-1, 1).substr($rprimer_r, $rr, 1) eq "GT") {
					my $bind_1 = substr($bind, 0, $rr);
					$bind_1 .= "1";
					$bind_1 .= substr($bind, $rr+1, length($bind)-$rr);
					$bind=$bind_1;
				}
			}
		}
		
		# GU pair
		for(my $rr=0;$rr<length($bind);$rr++) {
			if(substr($bind_5, $rr, 1) eq "0") {
				if(substr($primer_f, $pfl-$k+$rr-1, 1).substr($rprimer_r, $rr, 1) eq "TG" || substr($primer_f, $pfl-$k+$rr-1, 1).substr($rprimer_r, $rr, 1) eq "GT") {
					my $bind_1 = substr($bind_5, 0, $rr);
					$bind_1 .= "1";
					$bind_1 .= substr($bind_5, $rr+1, length($bind_5)-$rr);
					$bind_5=$bind_1;
				}
			}
		}

		# Single matched bases surrounded by mismatches are unstable,
		# so we remove them with the regexp (look ahead is needed otherwise
		# strings of consecutive match/mismatches are not caught)
		
		$bind =~s/01(?=[^1])/00/gx;
		$bind =~s/31(?=[^1])/30/gx;
		$bind =~s/21(?=[^1])/20/gx;
		$bind =~s/41(?=[^1])/40/gx;

		
		$bind =~s/011(?=[^1])/000/gx;
		$bind =~s/211(?=[^1])/200/gx;
		$bind =~s/311(?=[^1])/300/gx;
		$bind =~s/411(?=[^1])/400/gx;

		my $bind2 = $bind;

		$bind_5 =~s/01(?=[^1])/00/gx;
		$bind_5 =~s/31(?=[^1])/30/gx;
		$bind_5 =~s/21(?=[^1])/20/gx;
		$bind_5 =~s/41(?=[^1])/40/gx;

		
		$bind_5 =~s/011(?=[^1])/000/gx;
		$bind_5 =~s/211(?=[^1])/200/gx;
		$bind_5 =~s/311(?=[^1])/300/gx;
		$bind_5 =~s/411(?=[^1])/400/gx;

		# Short circuit if there's nothing to bind
		next unless $bind =~ /1{3,}/;
		
		# Find start and end of similarity
		my ($pb_init,$pb_end);
		my ($temp_init,$temp_end);
		my $one_temp=0;
		my $zero=0;
		my $one=0;
		my $long=0;
		my $position = rindex($bind_5, "1");
		my $qq = ($pfl>$prl ? $prl : $pfl);
		my $position_1 = index($bind_5, "1");
		
		my $param=0;
		my $ee=$bind_5;
		$ee = substr($ee,0,$position+1);
		$ee=reverse($ee);
		$ee = substr($ee,0,$position+1-$position_1);
		$ee=reverse($ee);
		$ee =~ s/3//g;
		$ee =~ s/2//g;
		$ee =~ s/4//g;
		my @long=();
		@long=split(/1+/,$ee);
		my $lent = @long;
		$ee =~ s/1//g;
		if($lent!=0){
			$param=length($ee)/$lent;
		}
		
		for ($l = $position_1; $l <= $position; $l++) {
			# at first I tried finding the initiating terminal bases with
			# regexps, but that was much slower ...
			if (substr($bind_5, $l, 3) == "111") {
				
				defined($temp_init) || ($temp_init = $l);
				
				while($l<=$position-1 && substr($bind_5, $l, 1)=="1") {
				
					if(substr($primer_f, $pfl-$k+$l-1, 1).substr($rprimer_r, $l, 1) eq "GC" 
					|| substr($primer_f, $pfl-$k+$l-1, 1).substr($rprimer_r, $l, 1) eq "CG") {
						$one_temp+=3;
					} elsif(substr($primer_f, $pfl-$k+$l-1, 1).substr($rprimer_r, $l, 1) eq "AT" 
					|| substr($primer_f, $pfl-$k+$l-1, 1).substr($rprimer_r, $l, 1) eq "TA") {
						$one_temp+=2;
					} elsif(substr($primer_f, $pfl-$k+$l-1, 1).substr($rprimer_r, $l, 1) eq "GT" 
					|| substr($primer_f, $pfl-$k+$l-1, 1).substr($rprimer_r, $l, 1) eq "TG") {
						$one_temp+=1;
					}
					$temp_end=$l;
					$l++;
				}
				
				if(substr($bind_5, $l, 1)=="1") {
					$temp_end=$l;
				}
				
				while($l<=$position && substr($bind_5, $l, 1)!="1") {
					if(substr($bind_5, $l, 1)=="0"){
						$zero++;
						$l++;
					}
				}
				$l--;

				if(defined($temp_init) && defined($temp_end)) {
					if($one_temp>$one) {
						$one=$one_temp;
						$pb_init = $temp_init;
						$pb_end = $temp_end;
					}
					
					if($zero > $param){
						$zero=0;
						$one_temp=0;
						$temp_init = undef;
						$temp_end = undef;
					} elsif($zero <= $param){
						$zero=0;
						$temp_end = undef;
					}
				}
			}
		}
		$bind1=func1($bind2,$k,$primer_f,$pfl,$rprimer_r,$pb_init,$pb_end);
		$bind1 =~s/01(?=[^1])/00/gx;
		$bind1 =~s/31(?=[^1])/30/gx;
		$bind1 =~s/21(?=[^1])/20/gx;
		$bind1 =~s/41(?=[^1])/40/gx;
		
		$bind1 =~s/011(?=[^1])/000/gx;
		$bind1 =~s/211(?=[^1])/200/gx;
		$bind1 =~s/311(?=[^1])/300/gx;
		$bind1 =~s/411(?=[^1])/400/gx;

		my $ss=$bind1;
		$ss = substr($ss,0,$pb_end+1);
		$ss=reverse($ss);
		$ss = substr($ss,0,$pb_end+1-$pb_init);
		$ss=reverse($ss);
		my $position_4 = rindex($ss, "1");
		my $position_3 = index($ss, "1");
		
		$pb_end = $pb_init+$position_4;
		$pb_init = $pb_init+$position_3;
		
		my $b_1 = substr($bind1, 0, $pb_init);
		my $b = substr($bind1,$pb_init,length($bind1)-$pb_init);
		$b_1 =~s/1/0/gx;
		$b_1 .= $b;
		$bind1=$b_1;
		
		my $b_2 = substr($bind1, 0, $pb_end+1);
		my $b_3 = substr($bind1,$pb_end+1,length($bind1)-$pb_end+1);
		$b_3 =~s/1/0/gx;
		$b_2 .= $b_3;
		$bind1=$b_2;
		
		my $yy = $bind1;
		$yy = substr($yy,0,$pb_end+1);
		$yy=reverse($yy);
		$yy = substr($yy,0,$pb_end+1-$pb_init);
		$yy =~ s/3//g;
		$yy =~ s/4//g;
		
		@long=();
		@long=split(/0+/,$yy);
		my $max = maxstr @long;
		$one_pp[$k]=length($max);

		if($bind==$bind1) {
			$score_y=0;
		}

		if (defined($pb_init)) {

			# deltaG calculation
			for $l ($pb_init .. $pb_end-1) {

				$score_y_temp=0;
				if(substr($bind, $l, 2) != substr($bind1, $l, 2)) {
					if (substr($bind, $l, 2) eq "33"){
						$score_y_temp=$oligo_dG{substr($primer_f, $pfl-$k+$l-1, 2).complement(substr($primer_f, $pfl-$k+$l-1, 2))};
						$score_y += $score_y_temp/2;
					}
					if (substr($bind, $l, 2) eq "30"){
						if(substr($primer_f, $pfl-$k+$l-1, 1).complement(substr($primer_f, $pfl-$k+$l-1, 1)) eq "AT" 
						|| substr($primer_f, $pfl-$k+$l-1, 1).complement(substr($primer_f, $pfl-$k+$l-1, 1)) eq "TA") {
							$score_y+=$oligo_dG{substr($primer_f, $pfl-$k+$l-1, 1).complement(substr($primer_f, $pfl-$k+$l-1, 1))};
						}
						$number++;
					}
					if (substr($bind, $l, 2) eq "31"){
						if(substr($primer_f, $pfl-$k+$l-1, 1).complement(substr($primer_f, $pfl-$k+$l-1, 1)) eq "AT" 
						|| substr($primer_f, $pfl-$k+$l-1, 1).complement(substr($primer_f, $pfl-$k+$l-1, 1)) eq "TA") {
							$score_y+=$oligo_dG{substr($primer_f, $pfl-$k+$l-1, 1).complement(substr($primer_f, $pfl-$k+$l-1, 1))};
						}
						$number++;
					}
					if (substr($bind, $l, 2) eq "32"){
						if(substr($primer_f, $pfl-$k+$l-1, 1).complement(substr($primer_f, $pfl-$k+$l-1, 1)) eq "AT" 
						|| substr($primer_f, $pfl-$k+$l-1, 1).complement(substr($primer_f, $pfl-$k+$l-1, 1)) eq "TA") {
							$score_y+=$oligo_dG{substr($primer_f, $pfl-$k+$l-1, 1).complement(substr($primer_f, $pfl-$k+$l-1, 1))};
						}
						$number++;
					}
					if (substr($bind, $l, 2) eq "34"){
						if(substr($primer_f, $pfl-$k+$l-1, 1).complement(substr($primer_f, $pfl-$k+$l-1, 1)) eq "AT" 
						|| substr($primer_f, $pfl-$k+$l-1, 1).complement(substr($primer_f, $pfl-$k+$l-1, 1)) eq "TA") {
							$score_y+=$oligo_dG{substr($primer_f, $pfl-$k+$l-1, 1).complement(substr($primer_f, $pfl-$k+$l-1, 1))};
						}
						$number++;
					}

					if (substr($bind, $l, 2) eq "40"){
						if(complement(substr($primer_f, $pfl-$k+$l-1, 1)).substr($primer_f, $pfl-$k+$l-1, 1) eq "AT" 
						|| complement(substr($primer_f, $pfl-$k+$l-1, 1)).substr($primer_f, $pfl-$k+$l-1, 1) eq "TA") {
							$score_y+=$oligo_dG{complement(substr($primer_f, $pfl-$k+$l-1, 1)).substr($primer_f, $pfl-$k+$l-1, 1)};
						}
					}
					if (substr($bind, $l, 2) eq "41"){
						if(complement(substr($primer_f, $pfl-$k+$l-1, 1)).substr($primer_f, $pfl-$k+$l-1, 1) eq "AT" 
						|| complement(substr($primer_f, $pfl-$k+$l-1, 1)).substr($primer_f, $pfl-$k+$l-1, 1) eq "TA") {
							$score_y+=$oligo_dG{complement(substr($primer_f, $pfl-$k+$l-1, 1)).substr($primer_f, $pfl-$k+$l-1, 1)};
						}
					}
					if (substr($bind, $l, 2) eq "42"){
						if(complement(substr($primer_f, $pfl-$k+$l-1, 1)).substr($primer_f, $pfl-$k+$l-1, 1) eq "AT" 
						|| complement(substr($primer_f, $pfl-$k+$l-1, 1)).substr($primer_f, $pfl-$k+$l-1, 1) eq "TA") {
							$score_y+=$oligo_dG{complement(substr($primer_f, $pfl-$k+$l-1, 1)).substr($primer_f, $pfl-$k+$l-1, 1)};
						}
					}
					if (substr($bind, $l, 2) eq "43"){
						if(complement(substr($primer_f, $pfl-$k+$l-1, 1)).substr($primer_f, $pfl-$k+$l-1, 1) eq "AT" 
						|| complement(substr($primer_f, $pfl-$k+$l-1, 1)).substr($primer_f, $pfl-$k+$l-1, 1) eq "TA") {
							$score_y+=$oligo_dG{complement(substr($primer_f, $pfl-$k+$l-1, 1)).substr($primer_f, $pfl-$k+$l-1, 1)};
						}
					}
				}
				next if substr($bind1, $l, 1) eq "2";
				next if substr($bind1, $l, 1) eq "3";
				next if substr($bind1, $l, 1) eq "4";
				next if substr($bind1, $l, 2) eq "00";
				next if substr($bind1, $l, 2) eq "01";
				next if substr($bind1, $l, 2) eq "03";
				next if substr($bind1, $l, 2) eq "02";
				next if substr($bind1, $l, 2) eq "04";
				next if substr($bind1, $l, 2) eq "10";
				next if substr($bind1, $l, 2) eq "14";
				next if substr($bind1, $l, 2) eq "13";
				next if substr($bind1, $l, 2) eq "12";
				if(substr($bind1, $l, 4) eq "1111" && substr($primer_f, $pfl-$k+$l-1, 4).substr($rprimer_r, $l, 4) eq "GGTCCTGG") {
					$score_p+=$oligo_dG{substr($primer_f, $pfl-$k+$l-1, 4).substr($rprimer_r, $l, 4)};
					$l = $l+2;
				} else {
					$score_p+=$oligo_dG{substr($primer_f, $pfl-$k+$l-1, 2).substr($rprimer_r, $l, 2)};	
				}
			}
			
			# init term corrections
			
			if(substr($primer_f, $pfl-$k+$pb_init-1, 1).substr($rprimer_r, $pb_init, 1) eq "AT" 
			|| substr($primer_f, $pfl-$k+$pb_init-1, 1).substr($rprimer_r, $pb_init, 1) eq "TA") {
				$score_p+=$oligo_dG{substr($primer_f, $pfl-$k+$pb_init-1, 1).substr($rprimer_r, $pb_init, 1)};
			}

			if(substr($primer_f, $pfl-$k+$pb_init-1, 1).substr($rprimer_r, $pb_init, 1) eq "GT" 
			|| substr($primer_f, $pfl-$k+$pb_init-1, 1).substr($rprimer_r, $pb_init, 1) eq "TG") {
				$score_p+=$oligo_dG{substr($primer_f, $pfl-$k+$pb_init-1, 1).substr($rprimer_r, $pb_init, 1)};
			}

			if(substr($primer_f, $pfl-$k+$pb_end-1, 1).substr($rprimer_r, $pb_end, 1) eq "AT" 
			|| substr($primer_f, $pfl-$k+$pb_end-1, 1).substr($rprimer_r, $pb_end, 1) eq "TA") {
				$score_p+=$oligo_dG{substr($primer_f, $pfl-$k+$pb_end-1, 1).substr($rprimer_r, $pb_end, 1)};
			}

			if(substr($primer_f, $pfl-$k+$pb_end-1, 1).substr($rprimer_r, $pb_end, 1) eq "GT" 
			|| substr($primer_f, $pfl-$k+$pb_end-1, 1).substr($rprimer_r, $pb_end, 1) eq "TG") {
				$score_p+=$oligo_dG{substr($primer_f, $pfl-$k+$pb_end-1, 1).substr($rprimer_r, $pb_end, 1)};
			}
			$score_pp[$k]=sprintf("%.2f",$score_p);
			
			$score_y=$score_y+$number*0.43;
			
			$score_p=$score_p-$score_y;
			
			# add to the hash ...
			$score[$k]=sprintf("%.2f",$score_p);
			$bind_string[$k]=$bind1;
			$rating_hash{$score[$k]}=$k;
			$init[$k]=$pb_init;
			$end[$k]=$pb_end;
		}
	}
	# sort the dimers to give the most stable:
	@score_sort = sort { $a <=> $b } @score;
	
	my $long_temp=0;
	my $s=0;
	for my $c(0 .. 2) {
		if(abs($score_sort[0])-abs($score_sort[$c]) > 1) {
			next;
		}
		my $pos_temp=$rating_hash{$score_sort[$c]};
		my $l=$one_pp[$pos_temp];
		if($l>$long_temp) {
			$long_temp = $l;
			$s = $score[$pos_temp];
		}
	}

	$score_sort[0]=$s;

	# Returns the most stable dimer
	return $score_sort[0];
}


sub draw_dimer {
	# This all seems a bit cumbersome!!
	my ($primer_f, $primer_r, $pos,$score,$c,$e,$d) = @_;
	
	my $rprimer_r=reverse($primer_r);
	my $dimer_binding="";
	my $binding_site="";
	my $binding_site1="";
	my $pr_space="";
	my $fspace="";
	my $rspace="";
	my $tang=0;
	my $shan=0;
	my $tianjin=0;
	my $beijing=0;
	my $hongqiao=0;
	my $nankai=0;
	my $heping=0;
	my $langfang=0;
	@result1 = ();

	my $fspace_def = $pl-$pfl>0 ? $pl-$pfl : 0;
	$fspace=" "x($fspace_def+($pos>$pl-1?$pos-$pl+1:0));
	
	if ($pos+1>=$pfl) {
		$rspace=" "x($pl-$pos-1);
	} else {
		$rspace=$fspace;
	}
	
	$pr_space=" "x($pfl-$pos-1);
	##make the space clear
	my $beiyi;
	if(length($fspace)>(length($rspace)+length($pr_space)))
	{
		$beiyi =" "x(length($fspace)-(length($rspace)+length($pr_space)));
	}
	else 
	{
		$beiyi =" "x((length($rspace)+length($pr_space))-length($fspace));
	}

	##end
	for my $j (0 .. $pos) {
		next unless $j < $prl;
		if (substr($bind_string[$pos],$j,1)==1) {
			$dimer_binding=$dimer_binding."|"
		} elsif (substr($bind_string[$pos],$j,1)==0) {
			$dimer_binding=$dimer_binding."."
		} elsif (substr($bind_string[$pos],$j,1)==3 || substr($bind_string[$pos],$j,1)==4) {
			$dimer_binding=$dimer_binding."*"
		}else {
			$dimer_binding=$dimer_binding." "
		}
	}
	my $position = rindex($bind_string[$pos], "1");
	my $position_1 = index($bind_string[$pos], "1");
	my $r=length($bind_string[$pos])-$position;

	$tang=$dimer_binding =~ tr/ / /;  
	$shan=$pr_space =~ tr/ / /;
	$tianjin=$rspace =~ tr/ / /;
	$beijing=$tang+$shan+$tianjin;
	$langfang=$tianjin+$shan;

	$number_1=length($fspace);
	$number_2=$beijing;
	$number_3=$number_2-$number_1+$position_1;
	$hongqiao=length("$fspace"."5' "."$primer_f");
	$nankai=length("$rspace"."   "."$pr_space"."$dimer_binding");
	$number_4=length($primer_f)-($hongqiao-$nankai)-1;

	$number_4=$number_4-$r+2;

	$number_5=$position_1+1;

	$number_3=$number_3-($beijing-$langfang+1)+2;
	$heping=length($rprimer_r);
	$nankai=length($dimer_binding);
	$number_6=length($rprimer_r)-($heping-$nankai)-$r+1;

	my @data;
	@data = split /\|/, $dimer_binding;
	shift @data; pop @data; 
	$binding_site1 = join '|', @data;
	$binding_site = "|".$binding_site1."|";

	$binding_site =~ s/ //g;

	my $len;
	my $ww = $bind_string[$pos];
	$ww = substr($ww,0,$end[$pos]+1);
	$ww=reverse($ww);
	$ww = substr($ww,0,$end[$pos]+1-$init[$pos]);
	$ww =~ s/3//g;
	$ww =~ s/4//g;
	$ww=reverse($ww);
	
	$len=length($ww);
	$sdelta=$score[$pos]/$len;
	$sdelta=abs(sprintf("%.4f",$sdelta));

	my $dndG = sprintf("%.4f",$c*(length($binding_site)**$e)+$d);
	my $D_value = sprintf("%.4f",abs($sdelta)-($c*(length($binding_site)**$e)+$d));

	push (@result, "$fpname\t");
	push (@result, "$fprimer_len\t");
	push (@result, "$rpname\t");
	push (@result, "$rprimer_len\t");
	push (@result, "$score\t");
	push (@result, "$sdelta\t");
	push (@result, "$number_3\t");
	push (@result, "$number_4\t");
	push (@result, "$number_5\t");
	push (@result, "$number_6\t");
	push (@result, "$dndG\t");
	push (@result, "$D_value\n");
	if(length($fspace)>=(length($rspace)+length($pr_space))) {
		push (@result, "$beiyi"."5' "."$primer_f"." 3'\n"."   "."$dimer_binding\n"."3' "."$rprimer_r"." 5'\n\n");
	}
	if(length($fspace)<(length($rspace)+length($pr_space))) {
		push (@result, "5' "."$primer_f"." 3'\n"."$beiyi"."   "."$dimer_binding\n"."$beiyi"."3' "."$rprimer_r"." 5'\n\n");
	}
	push (@result1, "$fpname\t$fprimer_len\t$rpname\t$rprimer_len\t$score\t$sdelta\t$number_3\t$number_4\t$number_5\t$number_6\t$dndG\t$D_value\n");
}

sub complement {
	$_ = shift;
	tr/AGCTagct/TCGAtcga/;
	return $_;
}